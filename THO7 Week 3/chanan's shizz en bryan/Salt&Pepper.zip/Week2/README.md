AlgorithmTimerGUI
=================

The algorithm timer and GUI